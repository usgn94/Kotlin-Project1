package languages.myapp

class C {
    var YouTube = listOf<String>("Easytuts4u","freeCodeCamp.org","Naresh i Technologies","ProgrammingKnowlwdge")
    fun print(){
        for(element in YouTube){
            println(element)
        }
    }
}