package languages.myapp

class Cpp {
    var YouTube = listOf<String>("C++ by Saurabh Shukla","LearningLad","CodeWithHarry","Naresh i Technologies","freeCodeCamp.org","ProgrammingKnowlwdge")
    fun print(){
        for(element in YouTube){
            println(element)
        }
    }
}