package languages.myapp

class Java {
    var YouTube = listOf<String>("easytuts4you","ProgrammingKnowledge","Programming with Mosh","Edureka","Inclusive Innovations","freeCodeCamp.org")
    fun print(){
        for(element in YouTube){
            println(element)
        }
    }
}