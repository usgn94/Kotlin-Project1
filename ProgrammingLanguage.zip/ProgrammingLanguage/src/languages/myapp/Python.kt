package languages.myapp

class Python {
    var YouTube = listOf<String>("Telusko","Programming with Mosh","Edureka","Tutorials Point","CodeWithHarry","freeCodeCamp.org","Harshit Vashisht")
    fun print(){
        for(element in YouTube){
            println(element)
        }
    }
}