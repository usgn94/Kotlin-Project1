package languages.myapp
fun c(){
    var interest = C()
    interest.print()
}
fun cpp(){
    var interest = Cpp()
    interest.print()
}
fun python(){
    var interest = Python()
    interest.print()
}
fun java(){
    var interest = Java()
    interest.print()
}
fun main(){
    var LanguageName = hashMapOf(1 to "C",2 to "Cpp",3 to "Python",4 to "Java")
    print("Enter a number to choose language to learn(1 for C,2 for Cpp,3 for python,4 for java) : ")
    var langNo = readLine()!!
    var n = langNo.toInt()
    if(n<5 && n>0) {
        println("\nThe following are the some top youtube channels for learning ${LanguageName[n]} \n")
    }
    else
        println("\nPlease enter a valid number")
    when(n) {
        1 -> c()
        2 -> cpp()
        3 -> python()
        4 -> java()
    }



}